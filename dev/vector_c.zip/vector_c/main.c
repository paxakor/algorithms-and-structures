#include <stdio.h>
#include "vector.h"

int main () {
  struct vector v;
  init(&v);
  int n = 100;
  for (int i = 0; i < n; ++i) {
    push_back(&v, (i - 1) * (i + 1));
  }
  for (int i = 0; i < n; ++i) {
    printf("%d\n", at(&v, i));
  }
  return 0;
}
